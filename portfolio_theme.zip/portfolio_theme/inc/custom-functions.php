<?php

//Custom Services Functions

function portfolio_custom_service_post() {
    $labels = array(
        'name'               => 'Services',
        'singular_name'      => 'Services',
        'menu_name'          => 'Services',
        'name_admin_bar'     => 'Services',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Services',
        'new_item'           => 'New Services',
        'edit_item'          => 'Edit Service',
        'view_item'          => 'View Services',
        'all_items'          => 'All Services',
        'search_items'       => 'Search Services',
        'parent_item_colon'  => 'Parent Services:',
        'not_found'          => 'No Services found.',
        'not_found_in_trash' => 'No Services found in Trash.',
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'services'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 110,
        'menu_icon'   => 'dashicons-admin-users',
        'supports'           => array('title', 'editor', 'thumbnail'),
    );

    register_post_type('services', $args);
}

add_action('init', 'portfolio_custom_service_post');

function add_custom_meta_boxes() {
    add_meta_box(
        'service_price',
        'Service Price',
        'service_price_callback',
        'services',
        'side',
        'default'
    );
    add_meta_box(
        'service_icon',
        'Service Icon',
        'service_icon_callback',
        'services',
        'side',
        'default'
    );
}

add_action('add_meta_boxes', 'add_custom_meta_boxes');

function service_price_callback($post) {
    wp_nonce_field('save_service_price', 'service_price_nonce');
    $value = get_post_meta($post->ID, '_service_price', true);
    echo '<label for="service_price">Price: </label>';
    echo '<input type="text" id="service_price" name="service_price" value="' . esc_attr($value) . '" />';
}

function service_icon_callback($post) {
    wp_nonce_field('save_service_icon', 'service_icon_nonce');
    $value = get_post_meta($post->ID, '_service_icon', true);
    echo '<label for="service_icon">Class Name Icon: </label>';
    echo '<input type="text" id="service_icon" name="service_icon" value="' . esc_attr($value) . '" />';
}

function save_custom_meta_boxes($post_id) {
    if (!isset($_POST['service_price_nonce']) || !wp_verify_nonce($_POST['service_price_nonce'], 'save_service_price')) {
        return;
    }
    if (!isset($_POST['service_icon_nonce']) || !wp_verify_nonce($_POST['service_icon_nonce'], 'save_service_icon')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['service_price'])) {
        $price = sanitize_text_field($_POST['service_price']);
        update_post_meta($post_id, '_service_price', $price);
    }

    if (isset($_POST['service_icon'])) {
        $icon = sanitize_text_field($_POST['service_icon']);
        update_post_meta($post_id, '_service_icon', $icon);
    }
}

add_action('save_post', 'save_custom_meta_boxes');

//Custom Projects Functions

function portfolio_custom_project_post() {
    $labels = array(
        'name'               => 'Projects',
        'singular_name'      => 'Projects',
        'menu_name'          => 'Projects',
        'name_admin_bar'     => 'Projects',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Project',
        'new_item'           => 'New Project',
        'edit_item'          => 'Edit Project',
        'view_item'          => 'View Project',
        'all_items'          => 'All Projects',
        'search_items'       => 'Search Projects',
        'parent_item_colon'  => 'Parent Projects:',
        'not_found'          => 'No Projects found.',
        'not_found_in_trash' => 'No Projects found in Trash.'
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'projects'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 95,
        'menu_icon'   => 'dashicons-text-page',
        'supports'           => array('title', 'thumbnail'),
        'taxonomies'         => array('post_tag'),
    );

    register_post_type('projects', $args);
}

add_action('init', 'portfolio_custom_project_post');




?>