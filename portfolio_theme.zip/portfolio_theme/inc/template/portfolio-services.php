<h1>Portfolio Services Options</h1>
<?php settings_errors(); ?>
<?php 
	
	$avatarImageser = esc_attr( get_option( 'avatar-imageser' ) );
    
?>

<form id="submitForm" method="post" action="options.php" class="portofolio-general-form">
	<?php settings_fields( 'protfolio-service-section' ); ?>
	<?php do_settings_sections( 'abdouu_protfolio_services' ); ?>
	<?php submit_button( 'Save Changes', 'primary', 'btnSubmit' ); ?>
</form>

<?php get_header() ?>

<?php
    $args = array('post_type' => 'services', 'posts_per_page' => 4 );
    $loop = new WP_Query( $args );
    if( $loop->have_posts() ):
?>
<section class="services section-padding" id="section_3">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 col-12 mx-auto">
                <div class="section-title-wrap d-flex justify-content-center align-items-center mb-5">
                    <?php $avatarImageser = esc_attr( get_option( 'avatar-imageser' ) ); ?>
                    <img src="<?php print $avatarImageser; ?>" class="avatar-image img-fluid" alt="">
                    <h2 class="text-white ms-4 mb-0">Services</h2>
                </div>
                <div class="row pt-lg-5">
                    <?php
                        while( $loop->have_posts() ): $loop->the_post(); 
                            $price = get_post_meta(get_the_ID(), '_service_price', true);
                            $icon = get_post_meta(get_the_ID(), '_service_icon', true); ?>
                                <div class="col-lg-6 col-12">
                                    <div class="services-thumb">
                                        <div class="d-flex flex-wrap align-items-center border-bottom mb-4 pb-3">
                                            <h3 class="mb-0"> <?php the_title(); ?></h3>
                                            <div class="services-price-wrap ms-auto">
                                                <p class="services-price-text mb-0">$<?php echo esc_html($price); ?></p>
                                                <div class="services-price-overlay"></div>
                                            </div>
                                        </div>
                                        <p><?php the_content(); ?></p>
                                        <a href="#" class="custom-btn custom-border-btn btn mt-3">Discover More</a>
                                        <?php if (!empty($icon)): ?>
                                            <div class="services-icon-wrap d-flex justify-content-center align-items-center">
                                                </i><i class="services-icon <?php print $icon; ?>"></i><!--bi-globe-->
                                            </div>
                                        <?php else:?>
                                            <div></div>
                                        <?php endif;?>
                                    </div>
                                </div>
                            <?php endwhile;
                                    
                        endif;	
                        wp_reset_postdata(); 
                    ?>
                </div>
            </div>
        </div>
    </div>
</section>






<?php get_footer() ?>