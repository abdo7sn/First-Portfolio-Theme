<h1>Portfolio Information Options</h1>
<?php settings_errors(); ?>
<?php 
	
	$Name = esc_attr( get_option( 'name' ) );
	$Birthday = esc_attr( get_option( 'birthday' ) );
	$Phone = esc_attr( get_option( 'phone' ) );
	$Email = esc_attr( get_option( 'email' ) );
    $Experiences = esc_attr( get_option( 'experiences' ) );
	$happyCustomers = esc_attr( get_option( 'happy-customers' ) );
	$projectFinished = esc_attr( get_option( 'project-finished' ) );
	$digitalAwards = esc_attr( get_option( 'digital-awards' ) );
    
?>

<form id="submitForm" method="post" action="options.php" class="sunset-general-form">
	<?php settings_fields( 'protfolio-settings-group' ); ?>
	<?php do_settings_sections( 'abdouu_protfolio' ); ?>
	<?php submit_button( 'Save Changes', 'primary', 'btnSubmit' ); ?>
</form>