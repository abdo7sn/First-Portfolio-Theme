<h1>Portfolio About Us Options</h1>
<hr>
<?php settings_errors(); ?>

<?php 
	$aboutImage = esc_attr( get_option( 'about-image' ) );
	$aboutContent = esc_attr( get_option( 'about-content' ) );
?>

<form id="submitForm" method="post" action="options.php" class="portofolio-general-form">
	<?php settings_fields( 'protfolio-about-section' ); ?>
	<?php do_settings_sections( 'abdouu_protfolio_aboutus' ); ?>
	<?php submit_button( 'Save Changes', 'primary', 'btnSubmit' ); ?>
</form>

<hr>
<?php get_header(); ?>
<section class="about section-padding" id="section_2">
    <div class="container">
        <div class="row">
			<div class="col-lg-6 col-12">
                <img src="<?php print $aboutImage; ?>" class="about-image img-fluid" alt="">
        	</div>

        	<div class="col-lg-6 col-12 mt-5 mt-lg-0">
                <div class="about-thumb">
					<div class="section-title-wrap d-flex justify-content-end align-items-center mb-4">
                        <h2 class="text-white me-4 mb-0">My Story</h2>
							<?php $avatarImage = esc_attr( get_option( 'avatar-image' ) ); ?>
							<img src="<?php print $avatarImage; ?>" class="avatar-image img-fluid" alt="">
                    </div>
					<?php $Name = esc_attr( get_option( 'name' ) ); ?>
					<h3 class="pt-2 mb-3">a little bit about <?php print $Name; ?></h3>
					<p><?php print $aboutContent ?></p>
                </div>
            </div>

        </div>
    </div>
</section>
<?php get_footer() ?>

    

