<?php


/*
	==========================================
	 Activate menus
	==========================================
*/

function protfolio_theme_setup() {
	add_theme_support('menus');

    register_nav_menu('primary', 'Primary Header Navigation');
    add_theme_support('post-thumbnails');

    add_theme_support('title-tag');

}

add_action('init', 'protfolio_theme_setup');


/*
	
@package protfoliotheme
	
	========================
		Information PAGE
	========================
*/

function protfolio_add_admin_page() {
	
	//Generate protfolio Admin Page
	add_menu_page( 'Protfolio Theme Options', 'Protfolio', 'manage_options', 'abdouu_protfolio', 'Protfolio_theme_create_page', 'dashicons-portfolio', 110 );
	 
	//Generate protfolio Admin Sub Pages
	add_submenu_page( 'abdouu_protfolio', 'Your Information Options', 'Your Information', 'manage_options', 'abdouu_protfolio', 'Protfolio_theme_create_page' );
	add_submenu_page( 'abdouu_protfolio', 'Theme Color Options', 'Theme Colors', 'manage_options', 'theme-colors', 'portfolio_theme_colors_page' );
	add_submenu_page( 'abdouu_protfolio', 'Hero Section Options', 'Hero Section', 'manage_options', 'abdouu_protfolio_herosection', 'Protfolio_theme_create_herosection' );
	add_submenu_page( 'abdouu_protfolio', 'About Us Settings', 'About US', 'manage_options', 'abdouu_protfolio_aboutus', 'Protfolio_theme_create_aboutus' );
	add_submenu_page( 'abdouu_protfolio', 'Sercives Settings', 'Sercives', 'manage_options', 'abdouu_protfolio_services', 'Protfolio_theme_create_services' );
	add_submenu_page( 'abdouu_protfolio', 'Projects Settings', 'Projects', 'manage_options', 'abdouu_protfolio_projects', 'Protfolio_theme_create_projects' );
	add_submenu_page( 'abdouu_protfolio', 'Contant Settings', 'Contant', 'manage_options', 'abdouu_protfolio_contant', 'Protfolio_theme_create_contant' );
}
add_action( 'admin_menu', 'protfolio_add_admin_page' );

//Activate custom settings
add_action( 'admin_init', 'protfolio_custom_settings' );

function protfolio_custom_settings() {
	//Information Options
	register_setting( 'protfolio-settings-group', 'name' );
	register_setting( 'protfolio-settings-group', 'birthday' );
	register_setting( 'protfolio-settings-group', 'phone' );
	register_setting( 'protfolio-settings-group', 'email' );
    register_setting( 'protfolio-settings-group', 'experiences' );
    register_setting( 'protfolio-settings-group', 'happy-customers' );
    register_setting( 'protfolio-settings-group', 'project-finished' );
    register_setting( 'protfolio-settings-group', 'digital-awards' );
	register_setting( 'protfolio-settings-group', 'companies' );
	register_setting( 'protfolio-settings-group', 'companies2' );
	register_setting( 'protfolio-settings-group', 'companies3' );
	register_setting( 'protfolio-settings-group', 'companies4' );
	register_setting( 'protfolio-settings-group', 'companies5' );

	add_settings_section( 'protfolio-information-options', 'Information Option', 'protfolio_information_options', 'abdouu_protfolio');
	
	add_settings_field( 'protfolio-name', 'Your Name', 'protfolio_name', 'abdouu_protfolio', 'protfolio-information-options');
	add_settings_field( 'protfolio-birthday', 'Your Birthday', 'protfolio_birthday', 'abdouu_protfolio', 'protfolio-information-options');
	add_settings_field( 'protfolio-phone', 'Your Phone', 'protfolio_phone', 'abdouu_protfolio', 'protfolio-information-options');
	add_settings_field( 'protfolio-email', 'Eamil', 'protfolio_email', 'abdouu_protfolio', 'protfolio-information-options');
    add_settings_field( 'protfolio-experiences', 'Experiences', 'protfolio_experiences', 'abdouu_protfolio', 'protfolio-information-options');
    add_settings_field( 'protfolio-appy-customers', 'Happy Customers', 'protfolio_happy_customers', 'abdouu_protfolio', 'protfolio-information-options');
    add_settings_field( 'protfolio-project-finished', 'Project Finished', 'protfolio_project_finished', 'abdouu_protfolio', 'protfolio-information-options');
    add_settings_field( 'protfolio-digital-awards', 'Digital Awards', 'protfolio_digital_awards', 'abdouu_protfolio', 'protfolio-information-options');
	add_settings_field( 'protfolio-companies', 'Companies You have had Worked', 'protfolio_companies', 'abdouu_protfolio', 'protfolio-information-options');
	add_settings_field( 'protfolio-companies2', '', 'protfolio_companies2', 'abdouu_protfolio', 'protfolio-information-options');
	add_settings_field( 'protfolio-companies3', '', 'protfolio_companies3', 'abdouu_protfolio', 'protfolio-information-options');
	add_settings_field( 'protfolio-companies4', '', 'protfolio_companies4', 'abdouu_protfolio', 'protfolio-information-options');
	add_settings_field( 'protfolio-companies5', '', 'protfolio_companies5', 'abdouu_protfolio', 'protfolio-information-options');

	//Hero Section Options
	register_setting( 'protfolio-hero-section', 'avatar-image' );
	register_setting( 'protfolio-hero-section', 'hero-image' );
	register_setting( 'protfolio-hero-section', 'hero-title' );
	register_setting( 'protfolio-hero-section', 'hero-description' );
	register_setting( 'protfolio-hero-section', 'hero-text-btn' );

	add_settings_section( 'protfolio-herosection-options', 'Hero Section Option', 'protfolio_herosection_options', 'abdouu_protfolio_herosection');

	add_settings_field( 'protfolio-herosection-avatarimage', 'Avatar Image', 'protfolio_herosection_avatarimage', 'abdouu_protfolio_herosection', 'protfolio-herosection-options');
	add_settings_field( 'protfolio-herosection-hero-image', 'Hero Image', 'protfolio_herosection_heroimage', 'abdouu_protfolio_herosection', 'protfolio-herosection-options');
	add_settings_field( 'protfolio-herosection-hero-title', 'Hero Title', 'protfolio_herosection_herotitle', 'abdouu_protfolio_herosection', 'protfolio-herosection-options');
	add_settings_field( 'protfolio-herosection-hero-description', 'Your Description', 'protfolio_herosection_herodescription', 'abdouu_protfolio_herosection', 'protfolio-herosection-options');
	add_settings_field( 'protfolio-herosection-hero-text-btn', 'Hero Text Button', 'protfolio_herosection_herotextbtn', 'abdouu_protfolio_herosection', 'protfolio-herosection-options');

	//About Section Options
	register_setting( 'protfolio-about-section', 'about-image' );
	register_setting( 'protfolio-about-section', 'about-content' );

	add_settings_section( 'protfolio-aboutus-options', 'About US Option', 'protfolio_aboutus_options', 'abdouu_protfolio_aboutus');

	add_settings_field( 'protfolio-abouus-image', 'About Image', 'protfolio_aboutus_image', 'abdouu_protfolio_aboutus', 'protfolio-aboutus-options');
	add_settings_field( 'protfolio-abouus-content', 'Type Your Content', 'protfolio_aboutus_content', 'abdouu_protfolio_aboutus', 'protfolio-aboutus-options');

	//Service Section Options
	register_setting( 'protfolio-service-section', 'avatar-imageser' );

	add_settings_section( 'protfolio-service-options', 'Services Option', 'protfolio_service_options', 'abdouu_protfolio_services');

	add_settings_field( 'protfolio-service-image', 'Avatar Image', 'protfolio_service_image', 'abdouu_protfolio_services', 'protfolio-service-options');

	//Projects Section Options
	register_setting( 'protfolio-projects-section', 'avatar-imagepro' );

	add_settings_section( 'protfolio-projects-options', 'Projects Option', 'protfolio_projects_options', 'abdouu_protfolio_projects');

	add_settings_field( 'protfolio-projects-image', 'Avatar Image', 'protfolio_projects_image', 'abdouu_protfolio_projects', 'protfolio-projects-options');

	//Contant Section Options
	register_setting( 'protfolio-contant-section', 'avatar-imagecon' );
	register_setting('protfolio-contant-section', 'facebook_url');
    register_setting('protfolio-contant-section', 'twitter_url');
    register_setting('protfolio-contant-section', 'instagram_url');
    register_setting('protfolio-contant-section', 'linkedin_url');
	register_setting('protfolio-contant-section', 'text_start_project');
	register_setting('protfolio-contant-section', 'glimpse_of_you');

	add_settings_section( 'protfolio-contant-options', 'Contant Option', 'protfolio_contant_options', 'abdouu_protfolio_contant');

	add_settings_field( 'protfolio-contant-image', 'Avatar Image', 'protfolio_contant_image', 'abdouu_protfolio_contant', 'protfolio-contant-options');
	add_settings_field('protfolio-contant-facebook-url', 'Facebook URL', 'protfolio_facebook_url_cb', 'abdouu_protfolio_contant','protfolio-contant-options');
	add_settings_field('protfolio-contant-twitter-url', 'Twitter URL', 'protfolio_twitter_url_cb', 'abdouu_protfolio_contant','protfolio-contant-options');
	add_settings_field('protfolio-contant-instagram-url', 'Instagram URL', 'protfolio_instagram_url_cb', 'abdouu_protfolio_contant','protfolio-contant-options');
	add_settings_field('protfolio-contant-linkedin-url', 'Linkedin URL', 'protfolio_linkedin_url_cb', 'abdouu_protfolio_contant','protfolio-contant-options');
	add_settings_field('protfolio-contant-text-start-project', 'Project start text', 'protfolio_text_start_project', 'abdouu_protfolio_contant','protfolio-contant-options');
	add_settings_field('protfolio-contant-glimpse-of-you', 'A glimpse of you', 'protfolio_glimpse_of_you', 'abdouu_protfolio_contant','protfolio-contant-options');
}

// Information Options Functions
function protfolio_information_options() {
	echo 'Customize your Information';
}

function protfolio_name() {
	$Name = esc_attr( get_option( 'name' ) );
	echo '<input type="text" name="name" value="'.$Name.'" placeholder="Your Name" />';
}

function protfolio_birthday() {
	$Birthday = esc_attr( get_option( 'birthday' ) );
	echo '<input type="date" name="birthday" value="'.$Birthday.'" placeholder="Your Birthday" />';
}

function protfolio_phone() {
	$Phone = esc_attr( get_option( 'phone' ) );
	echo '<input type="number" name="phone" value="'.$Phone.'" placeholder="Your Phone" />';
}

function protfolio_email() {
	$Email = esc_attr( get_option( 'email' ) );
	echo '<input type="email" name="email" value="'.$Email.'" placeholder="Email" />';
}

function protfolio_experiences() {
	$Experiences = esc_attr( get_option( 'experiences' ) );
	echo '<input type="number" name="experiences" value="'.$Experiences.'" placeholder="Years of Experiences" />';
}

function protfolio_happy_customers() {
	$happyCustomers = esc_attr( get_option( 'happy-customers' ) );
	echo '<input type="number" name="happy-customers" value="'.$happyCustomers.'" placeholder="Your Happy Customers" />';
}

function protfolio_project_finished() {
	$projectFinished = esc_attr( get_option( 'project-finished' ) );
	echo '<input type="number" name="project-finished" value="'.$projectFinished.'" placeholder="Your Project Finished" />';
}

function protfolio_digital_awards() {
	$digitalAwards = esc_attr( get_option( 'digital-awards' ) );
	echo '<input type="number" name="digital-awards" value="'.$digitalAwards.'" placeholder="Your Digital Awards" />';
}

function protfolio_companies(){
	$companiesImage = esc_attr( get_option( 'companies' ) );
	echo '<p>You can add up to 5 companies!</p>';
	if( empty($companiesImage) ){
		echo '<input type="button" class="button button-secondary" value="Upload Companie Logo" id="upload-companieimage"><input type="hidden" id="companie-picture" name="companies" value="" />';
	} else {
		echo '<input type="button" class="button button-secondary" value="Replace Companie Logo" id="upload-companieimage"><input type="hidden" id="companie-picture" name="companies" value="'.$companiesImage.'" /> <input type="button" class="button button-secondary" value="Remove" id="remove-picture-companies"> ';
	}
}
function protfolio_companies2(){
	$companiesImage2 = esc_attr( get_option( 'companies2' ) );
	if( empty($companiesImage2) ){
		echo '<input type="button" class="button button-secondary" value="Upload Companie Logo" id="upload-companieimage2"><input type="hidden" id="companie2-picture" name="companies2" value="" />';
	} else {
		echo '<input type="button" class="button button-secondary" value="Replace Companie Logo" id="upload-companieimage2"><input type="hidden" id="companie2-picture" name="companies2" value="'.$companiesImage2.'" /> <input type="button" class="button button-secondary" value="Remove" id="remove-picture-companies2"> ';
	}
}
function protfolio_companies3(){
	$companiesImage3 = esc_attr( get_option( 'companies3' ) );
	if( empty($companiesImage3) ){
		echo '<input type="button" class="button button-secondary" value="Upload Companie Logo" id="upload-companieimage3"><input type="hidden" id="companie3-picture" name="companies3" value="" />';
	} else {
		echo '<input type="button" class="button button-secondary" value="Replace Companie Logo" id="upload-companieimage3"><input type="hidden" id="companie3-picture" name="companies3" value="'.$companiesImage3.'" /> <input type="button" class="button button-secondary" value="Remove" id="remove-picture-companies3"> ';
	}
}
function protfolio_companies4(){
	$companiesImage4 = esc_attr( get_option( 'companies4' ) );
	if( empty($companiesImage4) ){
		echo '<input type="button" class="button button-secondary" value="Upload Companie Logo" id="upload-companieimage4"><input type="hidden" id="companie4-picture" name="companies4" value="" />';
	} else {
		echo '<input type="button" class="button button-secondary" value="Replace Companie Logo" id="upload-companieimage4"><input type="hidden" id="companie4-picture" name="companies4" value="'.$companiesImage4.'" /> <input type="button" class="button button-secondary" value="Remove" id="remove-picture-companies4"> ';
	}
}
function protfolio_companies5(){
	$companiesImage5 = esc_attr( get_option( 'companies5' ) );
	if( empty($companiesImage5) ){
		echo '<input type="button" class="button button-secondary" value="Upload Companie Logo" id="upload-companieimage5"><input type="hidden" id="companie5-picture" name="companies5" value="" />';
	} else {
		echo '<input type="button" class="button button-secondary" value="Replace Companie Logo" id="upload-companieimage5"><input type="hidden" id="companie5-picture" name="companies5" value="'.$companiesImage5.'" /> <input type="button" class="button button-secondary" value="Remove" id="remove-picture-companies5"> ';
	}
}


// Hero Section Options Functions
function protfolio_herosection_options(){
	echo 'Customize Hero Section';
}

function protfolio_herosection_avatarimage(){
	$avatarImage = esc_attr( get_option( 'avatar-image' ) );
	if( empty($avatarImage) ){
		echo '<input type="button" class="button button-secondary" value="Upload Avatar Image" id="upload-avatarimage"><input type="hidden" id="avatar-picture" name="avatar-image" value="" /> ';
	} else {
		echo '<input type="button" class="button button-secondary" value="Replace Avatar Image" id="upload-avatarimage"><input type="hidden" id="avatar-picture" name="avatar-image" value="'.$avatarImage.'" /> <input type="button" class="button button-secondary" value="Remove" id="remove-picture-avatar"> ';
	}
}

function protfolio_herosection_heroimage(){
	$heroImage = esc_attr( get_option( 'hero-image' ) );
	if( empty($heroImage) ){
		echo '<input type="button" class="button button-secondary" value="Upload Hero Image" id="upload-heroimage"><input type="hidden" id="hero-picture" name="hero-image" value="" /> ';
	} else {
		echo '<input type="button" class="button button-secondary" value="Replace Hero Image" id="upload-heroimage"><input type="hidden" id="hero-picture" name="hero-image" value="'.$heroImage.'" /> <input type="button" class="button button-secondary" value="Remove" id="remove-picture-hero"> ';
	}
}

function protfolio_herosection_herotitle() {
	$heroTitle = esc_attr( get_option( 'hero-title' ) );
	echo '<input type="text" name="hero-title" value="'.$heroTitle.'" placeholder="Hero Title" />';
}

function protfolio_herosection_herodescription() {
	$heroDescription = esc_attr( get_option( 'hero-description' ) );
	echo '<input type="text" name="hero-description" value="'.$heroDescription.'" placeholder="Your Description" /><p class="description">Who are you?</p>
	<div style="background-color: #e9eaeb; width: 150px;">';
}

function protfolio_herosection_herotextbtn() {
	$heroTextbtn = esc_attr( get_option( 'hero-text-btn' ) );
	echo '<input type="text" name="hero-text-btn" value="'.$heroTextbtn.'" placeholder="Hero Text Button" /><div style="background-color: #e9eaeb; width: 150px;">';
}
//About Us Options Functions
function protfolio_aboutus_options(){
	echo 'Customize About Us Page';
}

function protfolio_aboutus_image(){
	$aboutImage = esc_attr( get_option( 'about-image' ) );
	if( empty($aboutImage) ){
		echo '<input type="button" class="button button-secondary" value="Upload About Image" id="upload-aboutimage"><input type="hidden" id="about-picture" name="about-image" value="" /> ';
	} else {
		echo '<input type="button" class="button button-secondary" value="Replace About Image" id="upload-aboutimage"><input type="hidden" id="about-picture" name="about-image" value="'.$aboutImage.'" /><input type="button" class="button button-secondary" value="Remove" id="remove-picture-about"> ';
	}
}

function protfolio_aboutus_content(){
	$aboutContent = esc_attr( get_option( 'about-content' ) );
	echo '<textarea id="w3review" name="about-content" rows="15" cols="85">'.$aboutContent.'</textarea>';
}

//Services Options Function

function protfolio_service_options(){
	echo 'Customize Service Page';
}

function protfolio_service_image(){
	$avatarImageser = esc_attr( get_option( 'avatar-imageser' ) );
	if( empty($avatarImageser) ){
		echo '<input type="button" class="button button-secondary" value="Upload Avatar Image" id="upload-avatarimageser"><input type="hidden" id="avatarser-picture" name="avatar-imageser" value="" /> ';
	} else {
		echo '<input type="button" class="button button-secondary" value="Replace Avatar Image" id="upload-avatarimageser"><input type="hidden" id="avatarser-picture" name="avatar-imageser" value="'.$avatarImageser.'" /> <input type="button" class="button button-secondary" value="Remove" id="remove-picture-avatarser"> ';
	}
}

//Projects Options Function

function protfolio_projects_options(){
	echo 'Customize Projects Page';
}

function protfolio_projects_image(){
	$avatarImagepro = esc_attr( get_option( 'avatar-imagepro' ) );
	if( empty($avatarImagepro) ){
		echo '<input type="button" class="button button-secondary" value="Upload Avatar Image" id="upload-avatarimagepro"><input type="hidden" id="avatarpro-picture" name="avatar-imagepro" value="" /> ';
	} else {
		echo '<input type="button" class="button button-secondary" value="Replace Avatar Image" id="upload-avatarimagepro"><input type="hidden" id="avatarpro-picture" name="avatar-imagepro" value="'.$avatarImagepro.'" /> <input type="button" class="button button-secondary" value="Remove" id="remove-picture-avatarpro"> ';
	}
}
//Contant Options Function
function protfolio_contant_options(){
	echo 'Customize Contant Page';
}

function protfolio_contant_image(){
	$avatarImagecon = esc_attr( get_option( 'avatar-imagecon' ) );
	if( empty($avatarImagecon) ){
		echo '<input type="button" class="button button-secondary" value="Upload Avatar Image" id="upload-avatarimagecon"><input type="hidden" id="avatarcon-picture" name="avatar-imagecon" value="" /> ';
	} else {
		echo '<input type="button" class="button button-secondary" value="Replace Avatar Image" id="upload-avatarimagecon"><input type="hidden" id="avatarcon-picture" name="avatar-imagecon" value="'.$avatarImagecon.'" /> <input type="button" class="button button-secondary" value="Remove" id="remove-picture-avatarcon"> ';
	}
}

function protfolio_facebook_url_cb() {
	$facebook_url = esc_attr( get_option( 'facebook_url' ) );
    echo '<input type="url" id="facebook_url" name="facebook_url" value="' . esc_attr($facebook_url) . '" />';
}

function protfolio_twitter_url_cb() {
	$twitter_url = esc_attr( get_option( 'twitter_url' ) );
    echo '<input type="url" id="twitter_url" name="twitter_url" value="' . esc_attr($twitter_url) . '" />';
}

function protfolio_instagram_url_cb() {
	$instagram_url = esc_attr( get_option( 'instagram_url' ) );
    echo '<input type="url" id="instagram_url" name="instagram_url" value="' . esc_attr($instagram_url) . '" />';
}

function protfolio_linkedin_url_cb() {
	$linkedin_url = esc_attr( get_option( 'linkedin_url' ) );
    echo '<input type="url" id="linkedin_url" name="linkedin_url" value="' . esc_attr($linkedin_url) . '"  />';
}

function protfolio_text_start_project(){
	$text_start_project = esc_attr( get_option( 'text_start_project' ) );
	echo '<input type="text" name="text_start_project" value="'.$text_start_project.'" placeholder="Write who you are" class="regular-text ltr" />';
}

function protfolio_glimpse_of_you(){
	$glimpse_of_you = esc_attr( get_option( 'glimpse_of_you' ) );
	echo '<input type="text" name="glimpse_of_you" value="'.$glimpse_of_you.'" placeholder="Write a profile about yourself" class="regular-text ltr" />';
}

//====================================================================================
function protfolio_theme_create_page() {
	require_once( get_template_directory() . '/inc/template/protfolio-admin.php' );
}
function Protfolio_theme_create_herosection(){
	require_once( get_template_directory() . '/inc/template/protfolio-herosection.php' );
}
function Protfolio_theme_create_aboutus(){
	require_once( get_template_directory() . '/inc/template/portfolio-aboutus.php' );
}
function Protfolio_theme_create_services(){
	require_once( get_template_directory() . '/inc/template/portfolio-services.php' );
}
function Protfolio_theme_create_projects(){
	require_once( get_template_directory() . '/inc/template/portfolio-projects.php' );
}
function Protfolio_theme_create_contant() {
	require_once( get_template_directory() . '/inc/template/portfolio-contant.php' );
}
//Theme Color Functions
function portfolio_theme_colors_page() {
	if (!current_user_can('manage_options')) {
		return;
	}
	if (isset($_POST['submit'])) {
		update_option('primary_color', sanitize_hex_color($_POST['primary_color']));
		update_option('secondary_color', sanitize_hex_color($_POST['secondary_color']));
	}

	$primary_color = get_option('primary_color', '#3498db');
	$secondary_color = get_option('secondary_color', '#2ecc71');

	?>
	<div class="wrap">
		<h1>Theme Color Options</h1>
		<form method="post" action="">
			<label for="primary_color">Primary Color</label>
			<input type="text" id="primary_color" name="primary_color" value="<?php echo esc_attr($primary_color); ?>" class="my-color-field" />
			<br><br>
			<label for="secondary_color">Secondary Color</label>
			<input type="text" id="secondary_color" name="secondary_color" value="<?php echo esc_attr($secondary_color); ?>" class="my-color-field" />
			<br><br>
			<input type="submit" name="submit" value="Save Colors" class="button button-primary" />
		</form>
	</div>
	<?php
}

function portfolio_theme_customize_css() {
    $primary_color = get_option('primary_color', '#3498db');
    $secondary_color = get_option('secondary_color', '#2ecc71');
    ?>
    <style type="text/css">
        :root {
            --primary-color: <?php echo $primary_color; ?>;
            --secondary-color: <?php echo $secondary_color; ?>;
        }
    </style>
    <?php
}
add_action('wp_head', 'portfolio_theme_customize_css');


//Footer Function

function portfolio_register_footer_widgets() {
    register_sidebar(array(
        'name' => __('Footer Widget 1', 'my-custom-theme'),
        'id' => 'footer-widget-1',
        'before_widget' => '<div class="footer-widget">',
        'after_widget' => '</div>',
        'before_title' => '<h5 class="footer-title">',
        'after_title' => '</h5>',
    ));
    register_sidebar(array(
        'name' => __('Footer Widget 2', 'my-custom-theme'),
        'id' => 'footer-widget-2',
        'before_widget' => '<div class="footer-widget">',
        'after_widget' => '</div>',
        'before_title' => '<h5 class="footer-title">',
        'after_title' => '</h5>',
    ));
    register_sidebar(array(
        'name' => __('Footer Widget 3', 'my-custom-theme'),
        'id' => 'footer-widget-3',
        'before_widget' => '<div class="footer-widget">',
        'after_widget' => '</div>',
        'before_title' => '<h5 class="footer-title">',
        'after_title' => '</h5>',
    ));
}
add_action('widgets_init', 'portfolio_register_footer_widgets');


?>