<?php

/*
	@package portfoliotheme

	========================
		FRONT-END ENQUEUE FUNCTIONS
	========================
*/

function portfolio_load_scripts(){
	
	wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'fonts-gstatic', 'https://fonts.gstatic.com', array(), '1.0.0', 'all' );
    wp_enqueue_style( 'fonts-googleapis', 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&display=swap', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css', array(), '3.3.6', 'all' );
	wp_enqueue_style( 'bootstrap-icon', get_template_directory_uri() . '/css/bootstrap-icons.css', array(), '3.3.6', 'all' );
	wp_enqueue_style( 'magnific', get_template_directory_uri() . '/css/magnific-popup.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'portfolio-style', get_template_directory_uri() . '/css/templatemo-first-portfolio-style.css', array(), '1.0.0', 'all' );

	
	wp_enqueue_script( 'jquery', get_template_directory_uri() . '/js/jquery.min.js', array('jquery'), '1.11.3', true );
	wp_enqueue_script( 'bootstrap-js', get_template_directory_uri() . '/js/bootstrap.min.js', array('jquery'), '3.3.6', true );
    wp_enqueue_script( 'jquery-sticky', get_template_directory_uri() . '/js/jquery.sticky.js', array('jquery'), '1.11.3', true );
	wp_enqueue_script( 'click-scroll', get_template_directory_uri() . '/js/click-scroll.js', array('jquery'), null, true );
	wp_enqueue_script( 'jquery-magnific-popup', get_template_directory_uri() . '/js/jquery.magnific-popup.min.js', array('jquery'), '1.11.3', true );
	wp_enqueue_script( 'magnific-popup', get_template_directory_uri() . '/js/magnific-popup-options.js', array('jquery'), null, true );
	wp_enqueue_script( 'custom', get_template_directory_uri() . '/js/custom.js', array('jquery'), null, true );

}
add_action( 'wp_enqueue_scripts', 'portfolio_load_scripts' );

/*
		
	========================
		ADMIN ENQUEUE FUNCTIONS
	========================
*/
//Admin
function portfolio_load_admin_scripts( $hook ){
	//echo $hook;
	if( 'protfolio_page_abdouu_protfolio_herosection' == $hook ){ 
	
		wp_register_style( 'portfolio_admin', get_template_directory_uri() . '/css/portfolio.admin.css', array(), '1.0.0', 'all' );
		wp_enqueue_style( 'portfolio_admin' );
		
		wp_enqueue_media();
		
		wp_register_script( 'portfolio-admin-script', get_template_directory_uri() . '/js/portfolio.admin.js', array('jquery'), '1.0.0', true );
		wp_enqueue_script( 'portfolio-admin-script' );
	
	} 
	else { return; }
}
add_action( 'admin_enqueue_scripts', 'portfolio_load_admin_scripts' );


//Color
function portfolio_load_color_scripts( $hook ){
	//echo $hook;
	if( 'protfolio_page_theme-colors' == $hook ){ 
		wp_enqueue_script('jquery');
		
		wp_enqueue_script('wp-color-picker');
    	wp_enqueue_script('my-custom-script', get_template_directory_uri() . '/js/portfoilo-color.admin.js', array('wp-color-picker'), false, true);
	
	} 
	else { return; }
}
add_action( 'admin_enqueue_scripts', 'portfolio_load_color_scripts' );


//About
function portfolio_load_about_scripts( $hook ){
	//echo $hook;
	if( 'protfolio_page_abdouu_protfolio_aboutus' == $hook ){ 
		wp_enqueue_media();
		
		wp_register_script( 'portfolio-admin-script-about', get_template_directory_uri() . '/js/portfolio-about.admin.js', array('jquery'), '1.0.0', true );
		wp_enqueue_script( 'portfolio-admin-script-about' );
	
	} else { return; }

}
add_action( 'admin_enqueue_scripts', 'portfolio_load_about_scripts' );


//Service
function portfolio_load_service_scripts( $hook ){
	//echo $hook;
	if( 'protfolio_page_abdouu_protfolio_services' == $hook ){ 
		wp_enqueue_media();
		
		wp_register_script( 'portfolio-admin-script-service', get_template_directory_uri() . '/js/portfolio-service.admin.js', array('jquery'), '1.0.0', true );
		wp_enqueue_script( 'portfolio-admin-script-service' );
	
	} else { return; }

}
add_action( 'admin_enqueue_scripts', 'portfolio_load_service_scripts' );

//Projects
function portfolio_load_projects_scripts( $hook ){
	//echo $hook;
	if( 'protfolio_page_abdouu_protfolio_projects' == $hook ){ 
		wp_enqueue_media();
		
		wp_register_script( 'portfolio-admin-script-projects', get_template_directory_uri() . '/js/portfolio-projects.admin.js', array('jquery'), '1.0.0', true );
		wp_enqueue_script( 'portfolio-admin-script-projects' );
	
	} else { return; }

}
add_action( 'admin_enqueue_scripts', 'portfolio_load_projects_scripts' );

//Contant
function portfolio_load_contant_scripts( $hook ){
	//echo $hook;
	if( 'protfolio_page_abdouu_protfolio_contant' == $hook ){ 
		wp_enqueue_media();
		
		wp_register_script( 'portfolio-admin-script-contant', get_template_directory_uri() . '/js/portfolio-contant.admin.js', array('jquery'), '1.0.0', true );
		wp_enqueue_script( 'portfolio-admin-script-contant' );
	
	} else { return; }

}
add_action( 'admin_enqueue_scripts', 'portfolio_load_contant_scripts' );

//Company Logo
function portfolio_add_company_logo( $hook ){
	if( 'toplevel_page_abdouu_protfolio' == $hook ){
		wp_enqueue_media();

		wp_register_script( 'portfolio-admin-script-add', get_template_directory_uri() . '/js/portfolio-add.admin.js', array('jquery'), '1.0.0', true );
		wp_enqueue_script( 'portfolio-admin-script-add' );

	}
	else { return; }
}
add_action( 'admin_enqueue_scripts', 'portfolio_add_company_logo' );


?>