jQuery(document).ready( function($){
	
	var mediaUploader;

	//About Image
	$('#upload-aboutimage').on('click',function(e) {
		e.preventDefault();
		if( mediaUploader ){
			mediaUploader.open();
			return;
		}
			
		mediaUploader = wp.media.frames.file_frame = wp.media({
			title: 'Choose a About Picture',
			button: {
				text: 'Choose Picture'
			},
			multiple: false
		});


		mediaUploader.on('select', function(){
			attachment = mediaUploader.state().get('selection').first().toJSON();
			$('#about-picture').val(attachment.url);
		});

		mediaUploader.open();
	
	});

	//remove about image
	$('#remove-picture-about').on('click',function(e){
		e.preventDefault();
		var answer = confirm("Are you sure you want to remove your About Image?");
		if( answer == true ){
			$('#about-picture').val('');
			$('.portofolio-general-form').submit();
		}
		return;
	});
});
