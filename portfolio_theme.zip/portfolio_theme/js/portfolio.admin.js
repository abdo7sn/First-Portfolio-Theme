jQuery(document).ready( function($){
	
	var mediaUploader;

	// Avatar Image
	$('#upload-avatarimage').on('click',function(e) {
		e.preventDefault();
		if( mediaUploader ){
			mediaUploader.open();
			return;
		}
		
		mediaUploader = wp.media.frames.file_frame = wp.media({
			title: 'Choose a Avatar Picture',
			button: {
				text: 'Choose Picture'
			},
			multiple: false
		});


		mediaUploader.on('select', function(){
			attachment = mediaUploader.state().get('selection').first().toJSON();
			$('#avatar-picture').val(attachment.url);
		});

		mediaUploader.open();
		
	});

	//Hero Image
	$('#upload-heroimage').on('click',function(e) {
		e.preventDefault();
		if( mediaUploader ){
			mediaUploader.open();
			return;
		}
		
		mediaUploader = wp.media.frames.file_frame = wp.media({
			title: 'Choose a Hero Picture',
			button: {
				text: 'Choose Picture'
			},
			multiple: false
		});


		mediaUploader.on('select', function(){
			attachment = mediaUploader.state().get('selection').first().toJSON();
			$('#hero-picture').val(attachment.url);
		});

		mediaUploader.open();
	});
		
	//remove avatar image
	$('#remove-picture-avatar').on('click',function(e){
		e.preventDefault();
		var answer = confirm("Are you sure you want to remove your Avatar Image?");
		if( answer == true ){
			$('#avatar-picture').val('');
			$('.portofolio-general-form').submit();
		}
		return;
	});

	//remove hero image
	$('#remove-picture-hero').on('click',function(e){
		e.preventDefault();
		var answer = confirm("Are you sure you want to remove your Hero Image?");
		if( answer == true ){
			$('#hero-picture').val('');
			$('.portofolio-general-form').submit();
		}
		return;
	});

});
