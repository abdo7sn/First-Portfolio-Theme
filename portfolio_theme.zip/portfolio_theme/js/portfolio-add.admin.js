jQuery(document).ready( function($){
	
	var mediaUploader;

	//Companies Logo
	$('#upload-companieimage').on('click',function(e) {
		e.preventDefault();
		if( mediaUploader ){
			mediaUploader.open();
			return;
		}
			
		mediaUploader = wp.media.frames.file_frame = wp.media({
			title: 'Choose a Companie Logo',
			button: {
				text: 'Choose Logo'
			},
			multiple: false
		});


		mediaUploader.on('select', function(){
			attachment = mediaUploader.state().get('selection').first().toJSON();
			$('#companie-picture').val(attachment.url);
		});

		mediaUploader.open();
	
    });
	//2
	$('#upload-companieimage2').on('click',function(e) {
		e.preventDefault();
		if( mediaUploader ){
			mediaUploader.open();
			return;
		}
			
		mediaUploader = wp.media.frames.file_frame = wp.media({
			title: 'Choose a Companie Logo',
			button: {
				text: 'Choose Logo'
			},
			multiple: false
		});


		mediaUploader.on('select', function(){
			attachment = mediaUploader.state().get('selection').first().toJSON();
			$('#companie2-picture').val(attachment.url);
		});

		mediaUploader.open();
	
    });

	//3
	$('#upload-companieimage3').on('click',function(e) {
		e.preventDefault();
		if( mediaUploader ){
			mediaUploader.open();
			return;
		}
			
		mediaUploader = wp.media.frames.file_frame = wp.media({
			title: 'Choose a Companie Logo',
			button: {
				text: 'Choose Logo'
			},
			multiple: false
		});


		mediaUploader.on('select', function(){
			attachment = mediaUploader.state().get('selection').first().toJSON();
			$('#companie3-picture').val(attachment.url);
		});

		mediaUploader.open();
	
    });

	//4
	$('#upload-companieimage4').on('click',function(e) {
		e.preventDefault();
		if( mediaUploader ){
			mediaUploader.open();
			return;
		}
			
		mediaUploader = wp.media.frames.file_frame = wp.media({
			title: 'Choose a Companie Logo',
			button: {
				text: 'Choose Logo'
			},
			multiple: false
		});


		mediaUploader.on('select', function(){
			attachment = mediaUploader.state().get('selection').first().toJSON();
			$('#companie4-picture').val(attachment.url);
		});

		mediaUploader.open();
	
    });

	//5
	$('#upload-companieimage5').on('click',function(e) {
		e.preventDefault();
		if( mediaUploader ){
			mediaUploader.open();
			return;
		}
			
		mediaUploader = wp.media.frames.file_frame = wp.media({
			title: 'Choose a Companie Logo',
			button: {
				text: 'Choose Logo'
			},
			multiple: false
		});


		mediaUploader.on('select', function(){
			attachment = mediaUploader.state().get('selection').first().toJSON();
			$('#companie5-picture').val(attachment.url);
		});

		mediaUploader.open();
	
    });


	//remove Companies Logo
	$('#remove-picture-companies').on('click',function(e){
		e.preventDefault();
		var answer = confirm("Are you sure you want to remove your Companies Image?");
		if( answer == true ){
			$('#companie-picture').val('');
			$('.portofolio-general-form').submit();
		}
		return;
	});

	$('#remove-picture-companies2').on('click',function(e){
		e.preventDefault();
		var answer = confirm("Are you sure you want to remove your Companies Image?");
		if( answer == true ){
			$('#companie2-picture').val('');
			$('.portofolio-general-form').submit();
		}
		return;
	});

	$('#remove-picture-companies3').on('click',function(e){
		e.preventDefault();
		var answer = confirm("Are you sure you want to remove your Companies Image?");
		if( answer == true ){
			$('#companie3-picture').val('');
			$('.portofolio-general-form').submit();
		}
		return;
	});

	$('#remove-picture-companies4').on('click',function(e){
		e.preventDefault();
		var answer = confirm("Are you sure you want to remove your Companies Image?");
		if( answer == true ){
			$('#companie4-picture').val('');
			$('.portofolio-general-form').submit();
		}
		return;
	});

	$('#remove-picture-companies5').on('click',function(e){
		e.preventDefault();
		var answer = confirm("Are you sure you want to remove your Companies Image?");
		if( answer == true ){
			$('#companie5-picture').val('');
			$('.portofolio-general-form').submit();
		}
		return;
	});

});