<footer class="site-footer">
    <div class="container">
        <div class="row">

                    <?php if (is_active_sidebar('footer-widget-1')) : ?>
                        <div class="col-md-4">
                            <?php dynamic_sidebar('footer-widget-1'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (is_active_sidebar('footer-widget-2')) : ?>
                        <div class="col-md-4">
                            <?php dynamic_sidebar('footer-widget-2'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (is_active_sidebar('footer-widget-3')) : ?>
                        <div class="col-md-4">
                            <?php dynamic_sidebar('footer-widget-3'); ?>
                        </div>
                    <?php endif; ?>
                    <div class="row mt-4">
            <div class="col-md-12 text-center">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?> Portfolio. All Rights Reserved.</p>
            </div>
        
        </div>
    </div>
</footer>