    <section class="about section-padding" id="section_2">
                <div class="container">
                    <div class="row">
                        <?php $aboutImage = esc_attr( get_option( 'about-image' ) ); ?>
                        <div class="col-lg-6 col-12">
                            <img src="<?php print $aboutImage ?>" class="about-image img-fluid" alt="">
                        </div>

                        <div class="col-lg-6 col-12 mt-5 mt-lg-0">
                            <div class="about-thumb">

                                <div class="section-title-wrap d-flex justify-content-end align-items-center mb-4">
                                    <h2 class="text-white me-4 mb-0">My Story</h2>

                                    <?php $avatarImage = esc_attr( get_option( 'avatar-image' ) ); ?>
                                    <img src="<?php print $avatarImage; ?>" class="avatar-image img-fluid" alt="">
                                </div>
                                <?php  $Name = esc_attr( get_option( 'name' ) ); ?>
                                <h3 class="pt-2 mb-3">a little bit about <?php print $Name; ?></h3>
                                <?php $aboutContent = esc_attr( get_option( 'about-content' ) ); ?>
                                <p><?php print $aboutContent ?></p>

                                <!--<p>You are allowed to use this template for your websites. You are not allowed to redistribute the template ZIP file on any other website. Please contact us for more info.</p>-->
                            </div>
                        </div>

                    </div>
                </div>
    </section>
    <?php 
        
        $Name = esc_attr( get_option( 'name' ) );
        $Birthday = esc_attr( get_option( 'birthday' ) );
        $Phone = esc_attr( get_option( 'phone' ) );
        $Email = esc_attr( get_option( 'email' ) );
        $Experiences = esc_attr( get_option( 'experiences' ) );
        $happyCustomers = esc_attr( get_option( 'happy-customers' ) );
        $projectFinished = esc_attr( get_option( 'project-finished' ) );
        $digitalAwards = esc_attr( get_option( 'digital-awards' ) );
        
    ?>
    <section class="featured section-padding">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-6 col-12">
                            <div class="profile-thumb">
                                <div class="profile-title">
                                    <h4 class="mb-0">Information</h4>
                                </div>

                                <div class="profile-body">
                                    <p>
                                        <span class="profile-small-title">Name</span> 
                                        <span><?php print $Name; ?></span>
                                    </p>

                                    <p>
                                        <span class="profile-small-title">Birthday</span> 
                                        <span><?php print $Birthday; ?></span>
                                    </p>

                                    <p>
                                        <span class="profile-small-title">Phone</span> 
                                         <span><a href="tel: 305-240-9671"><?php print $Phone; ?></a></span>
                                    </p>

                                    <p>
                                        <span class="profile-small-title">Email</span> 
                                        <span><a href="mailto:hello@josh.design"><?php print $Email; ?></a></span>
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-12 mt-5 mt-lg-0">
                            <div class="about-thumb">
                                <div class="row">
                                    <div class="col-lg-6 col-6 featured-border-bottom py-2">
                                        <strong class="featured-numbers"><?php print $Experiences; ?>+</strong>

                                        <p class="featured-text">Years of Experiences</p>
                                    </div>

                                    <div class="col-lg-6 col-6 featured-border-start featured-border-bottom ps-5 py-2">
                                        <strong class="featured-numbers"><?php print $happyCustomers; ?></strong>

                                        <p class="featured-text">Happy Customers</p>
                                    </div>

                                    <div class="col-lg-6 col-6 pt-4">
                                        <strong class="featured-numbers"><?php print $projectFinished; ?></strong>

                                        <p class="featured-text">Project Finished</p>
                                    </div>

                                    <div class="col-lg-6 col-6 featured-border-start ps-5 pt-4">
                                        <strong class="featured-numbers"><?php print $digitalAwards; ?>+</strong>

                                        <p class="featured-text">Digital Awards</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
    </section>


    <section class="clients section-padding">
                <div class="container">
                    <div class="row align-items-center">

                        <div class="col-lg-12 col-12">
                            <h3 class="text-center mb-5">Companies I've had worked</h3>
                        </div>

                        <div class="col-lg-2 col-4 ms-auto clients-item-height">
                            <?php $companiesImage = esc_attr( get_option( 'companies' ) ); ?>
                            <img src="<?php print $companiesImage ?>" class="clients-image img-fluid" alt="">
                        </div>

                        <div class="col-lg-2 col-4 clients-item-height">
                        <?php $companiesImage2 = esc_attr( get_option( 'companies2' ) ); ?>
                            <img src="<?php print $companiesImage2 ?>" class="clients-image img-fluid" alt="">
                        </div>

                        <div class="col-lg-2 col-4 clients-item-height">
                        <?php $companiesImage3 = esc_attr( get_option( 'companies3' ) ); ?>
                            <img src="<?php print $companiesImage3 ?>" class="clients-image img-fluid" alt="">
                        </div>

                        <div class="col-lg-2 col-4 clients-item-height">
                        <?php $companiesImage4 = esc_attr( get_option( 'companies4' ) ); ?>
                            <img src="<?php print $companiesImage4 ?>" class="clients-image img-fluid" alt="">
                        </div>

                        <div class="col-lg-2 col-4 me-auto clients-item-height">
                            <?php $companiesImage5 = esc_attr( get_option( 'companies5' ) ); ?>
                            <img src="<?php print $companiesImage5 ?>" class="clients-image img-fluid" alt="">
                        </div>

                    </div>
                </div>
    </section>