<section class="preloader">
    <div class="spinner">
        <span class="spinner-rotate"></span>    
    </div>
</section>

<nav class="navbar navbar-expand-lg">
    <?php $primary_color = get_option('primary_color', '#3498db'); ?>
    <div class="container" style="background-color: <?php echo $primary_color; ?>;">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a href="<?php echo home_url(); ?>" class="navbar-brand mx-auto mx-lg-0"><?php bloginfo('name'); ?></a>

        <?php $Phone = esc_attr( get_option( 'phone' ) );?>
        <div class="d-flex align-items-center d-lg-none">
            <i class="navbar-icon bi-telephone-plus me-3"></i>
            <a class="custom-btn btn" href="#section_5">
                <?php print $Phone; ?>
            </a>
        </div>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-lg-5">
                <?php
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'depth' => 2,
                        'container' => 'div',
                        'container_class' => 'collapse navbar-collapse',
                        'container_id' => 'bs-example-navbar-collapse-1',
                        'menu_class' => 'navbar-nav ml-auto',
                        'id_class' => 'nav-item',
                        'fallback_cb' => 'WP_Bootstrap_Navwalker::fallback',
                        'walker' => new WP_Bootstrap_Navwalker(),
                    ));
                ?>
            </ul>

            <div class="d-lg-flex align-items-center d-none ms-auto">
                <i class="navbar-icon bi-telephone-plus me-3"></i>
                    <a class="custom-btn btn" href="">
                        <?php print $Phone; ?>
                    </a>
            </div>
        </div>

    </div>
</nav>

</main>