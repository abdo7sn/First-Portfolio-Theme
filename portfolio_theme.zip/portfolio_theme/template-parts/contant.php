<section class="contact section-padding" id="section_5">
                    <div class="container">
                        <div class="row">

                            <div class="col-lg-6 col-md-8 col-12">
                                <div class="section-title-wrap d-flex justify-content-center align-items-center mb-5">
                                    <?php $avatarImagecon = esc_attr( get_option( 'avatar-imagecon' ) ); ?>
                                    <img src="<?php print $avatarImagecon; ?>" class="avatar-image img-fluid" alt="">

                                    <h2 class="text-white ms-4 mb-0">Say Hi</h2>
                                </div>
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-lg-3 col-md-6 col-12 pe-lg-0">
                                <div class="contact-info contact-info-border-start d-flex flex-column">
                                    <strong class="site-footer-title d-block mb-3">Services</strong>

                                    <ul class="footer-menu">
                                        <?php
                                            $args = array('post_type' => 'services', 'posts_per_page' => 4 );
                                            $loop = new WP_Query( $args );
                                            if( $loop->have_posts() ):
                                                while( $loop->have_posts() ): $loop->the_post(); 
                                        ?>
                                        <li class="footer-menu-item"><a href="#" class="footer-menu-link"><?php the_title(); ?></a></li>
                                        <?php endwhile;
                                            endif;	
                                            wp_reset_postdata(); 
                                        ?>
                                    </ul>

                                    <strong class="site-footer-title d-block mt-4 mb-3">Stay connected</strong>

                                    <ul class="social-icon">
                                        <?php
                                            $facebook_url = esc_attr( get_option( 'facebook_url' ) );
                                            $twitter_url = esc_attr( get_option( 'twitter_url' ) );
                                            $instagram_url = esc_attr( get_option( 'instagram_url' ) );
                                            $linkedin_url = esc_attr( get_option( 'linkedin_url' ) ); 
                                         ?>
                                        <li class="social-icon-item"><a href="<?php print $twitter_url; ?>" class="social-icon-link bi-x"></a></li>

                                        <li class="social-icon-item"><a href="<?php print $instagram_url; ?>" class="social-icon-link bi-instagram"></a></li>

                                        <li class="social-icon-item"><a href="<?php print $facebook_url; ?>" class="social-icon-link bi-facebook"></a></li>

                                        <li class="social-icon-item"><a href="<?php print $linkedin_url; ?>" class="social-icon-link bi-linkedin"></a></li>
                                    </ul>

                                    <strong class="site-footer-title d-block mt-4 mb-3">Start a project</strong>
                                    <?php $text_start_project = esc_attr( get_option( 'text_start_project' ) );?>
                                    <p class="mb-0"><?php print $text_start_project; ?></p>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-6 col-12 ps-lg-0">
                                <div class="contact-info d-flex flex-column">
                                    <strong class="site-footer-title d-block mb-3">About</strong>
                                    <?php $glimpse_of_you = esc_attr( get_option( 'glimpse_of_you' ) ); ?>
                                    <p class="mb-2"> <?php print $glimpse_of_you ?> </p>

                                    <strong class="site-footer-title d-block mt-4 mb-3">Email</strong>

                                    <p>
                                        <?php $Email = esc_attr( get_option( 'email' ) ); ?>
                                        <a href="mailto:<?php print $Email ?>">
                                            <?php print $Email ?>
                                        </a>
                                    </p>

                                    <strong class="site-footer-title d-block mt-4 mb-3">Call</strong>

                                    <p class="mb-0">
                                        <?php $Phone = esc_attr( get_option( 'phone' ) ); ?>
                                        <a href="tel: <?php print $Phone ?>">
                                            <?php print $Phone ?>
                                        </a>
                                    </p>
                                </div>
                            </div>

                            <div class="col-lg-6 col-12 mt-5 mt-lg-0">
                                <form action="#" method="get" class="custom-form contact-form" role="form">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-12">
                                            <div class="form-floating">
                                                <input type="text" name="name" id="name" class="form-control" placeholder="Name" required="">
                                                
                                                <label for="floatingInput">Name</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-12"> 
                                            <div class="form-floating">
                                                <input type="email" name="email" id="email" pattern="[^ @]*@[^ @]*" class="form-control" placeholder="Email address" required="">
                                                
                                                <label for="floatingInput">Email address</label>
                                            </div>
                                        </div>

                                        <?php
                                            $args = array('post_type' => 'services', 'posts_per_page' => 4 );
                                            $loop = new WP_Query( $args );
                                            if( $loop->have_posts() ):
                                                while( $loop->have_posts() ): $loop->the_post(); 
                                                $icon = get_post_meta(get_the_ID(), '_service_icon', true);
                                        ?>
                                        <div class="col-lg-3 col-md-6 col-6">
                                            <div class="form-check form-check-inline">
                                            <input name="<?php the_title(); ?>" type="checkbox" class="form-check-input" id="inlineCheckbox" value="1">
                                                <?php
                                                for ($i = 0; $i < 10; $i++) { ?>
                                                    <label class="form-check-label" for="inlineCheckbox<?php $i;?>">
                                                        <i class="<?php print $icon; ?> form-check-icon"></i>
                                                        <span class="form-check-label-text"><?php the_title(); ?></span>
                                                    </label>
                                               <?php } ?>
                                          </div>
                                        </div>
                                        <?php endwhile;
                                            endif;	
                                            wp_reset_postdata(); 
                                        ?>

                                        <div class="col-lg-12 col-12">
                                            <div class="form-floating">
                                                <textarea class="form-control" id="message" name="message" placeholder="Tell me about the project"></textarea>
                                                
                                                <label for="floatingTextarea">Tell me about the project</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-12 ms-auto">
                                            <button type="submit" class="form-control">Send</button>
                                        </div>

                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
</section>