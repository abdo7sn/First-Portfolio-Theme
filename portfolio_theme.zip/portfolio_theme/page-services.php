<?php get_header(); ?>

<?php get_template_part('template-parts/services'); ?>

<?php get_footer() ?>