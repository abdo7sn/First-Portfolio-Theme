<?php get_header(); ?>

<?php get_template_part('template-parts/about'); ?>

<?php get_footer() ?>