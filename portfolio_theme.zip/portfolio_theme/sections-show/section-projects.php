<?php
    $args = array('post_type' => 'projects', 'posts_per_page' => 3 );
    $loop = new WP_Query( $args );
    if( $loop->have_posts() ):
?>
<section class="projects section-padding" id="section_4">
    <div class="container">
        <div class="row">

            <div class="col-lg-8 col-md-8 col-12 ms-auto">
                <div class="section-title-wrap d-flex justify-content-center align-items-center mb-4">
                    <?php $avatarImagepro = esc_attr( get_option( 'avatar-imagepro' ) ); ?>
                    <img src="<?php print $avatarImagepro; ?>" class="avatar-image img-fluid" alt="">
                    <h2 class="text-white ms-4 mb-0">Projects</h2>
                </div>
            </div>

            <div class="clearfix"></div>
            <?php while( $loop->have_posts() ): $loop->the_post();
                $thumbnail_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
             ?>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="projects-thumb">
                        <div class="projects-info">
                        <?php
                            $tags = get_the_tags();
                            if (!empty($tags)) {
                                foreach ($tags as $tag) {
                                    echo '<small class="projects-tag">' . esc_html($tag->name) . '</small>';
                                }
                            }
                        ?>
                            <h3 class="projects-title"><?php the_title(); ?></h3>
                        </div>
                        <a href="<?php echo esc_url($thumbnail_url); ?>" class="popup-image">
                            <img src="<?php echo esc_url($thumbnail_url); ?>" class="projects-image img-fluid" alt="">
                        </a>
                    </div>
                </div>
                <?php endwhile;
                endif;	
                wp_reset_postdata(); 
            ?>
        </div>
    </div>
</section>