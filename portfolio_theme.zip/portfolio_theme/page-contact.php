<?php get_header(); ?>

<?php get_template_part('template-parts/contant'); ?>

<?php get_footer() ?>